package prog.unidad06.listas.ejercicio03.versionavanzada.reductores;

public class ReductorEnteroException extends RuntimeException {

}
