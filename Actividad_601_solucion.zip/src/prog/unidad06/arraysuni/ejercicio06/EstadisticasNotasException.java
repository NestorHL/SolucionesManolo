package prog.unidad06.arraysuni.ejercicio06;

/**
 * Excepción que se lanza desde EstadisticasNotas
 */
public class EstadisticasNotasException extends Exception {

}
