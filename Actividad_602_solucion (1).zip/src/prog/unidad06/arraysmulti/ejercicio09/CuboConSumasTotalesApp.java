package prog.unidad06.arraysmulti.ejercicio09;

import java.util.Scanner;
import prog.unidad06.arraysmulti.ejercicio06.TablaEnteraUtils;

/**
 * Solicita un cubo al usuario y calcula la suma de filas columnas, segmentos y planos
 */
public class CuboConSumasTotalesApp {
  // Dimensiones del cubo (damos una mas para el sitio para los totales)
  private static final int PLANOS = 5;
  private static final int FILAS = 4;
  private static final int COLUMNAS = 3;
  
  // Separacion entre columnas
  private static final int SEPARACION = 2;

  public static void main(String[] args) {
    // para leer desde teclado
    Scanner sc = new Scanner(System.in);
    
    // Cabecera
    System.out.println("CUBO CON SUMAS TOTALES");
    
    // Creamos el cubo
    int[][][] cubo = new int[PLANOS][FILAS][COLUMNAS];
    
    // Para cada plano
    for (int plano = 0; plano < (PLANOS - 1); plano++) {
      // Para cada fila
      for (int fila = 0; fila < (FILAS - 1 ); fila++) {
        // Para cada columna
        for (int columna = 0; columna < (COLUMNAS - 1); columna++) {
          // Solicitamos el número de la casilla
          System.out.print("Introduzca el número correspondiente a la casilla ("
            + (plano + 1) + ", " + (fila + 1) + ", " + (columna + 1) + "): ");
          int numero = Integer.parseInt(sc.nextLine());
          // Almacenamos el número en la casilla correspondiente
          cubo[plano][fila][columna] = numero;
          // Sumamos el valor a la suma total de la fila
          cubo[plano][fila][COLUMNAS - 1] += numero;
          // Ahora a la suma total de la columna
          cubo[plano][FILAS - 1][columna] += numero;
          // Al total del plano
          cubo[plano][FILAS - 1][COLUMNAS - 1] += numero;
          // Al total del segmento
          cubo[PLANOS - 1][fila][columna] += numero;
          // Al total de la fila del segmento
          cubo[PLANOS - 1][fila][COLUMNAS - 1] += numero;
          // Al total de la columna del segmento
          cubo[PLANOS - 1][FILAS - 1][columna] += numero;
          // Y por último al total definitivo
          cubo[PLANOS - 1][FILAS - 1][COLUMNAS - 1] += numero;
        }
      }
    }
    
    // Imprimimos los planos
    for (int plano = 0; plano < PLANOS; plano++) {
      // Titulo del plano
      System.out.println("Plano " + (plano + 1));
      // Usamos TablaEnteraUtils para imprimir el plano
      TablaEnteraUtils.imprimeTabla(cubo[plano], SEPARACION);
    }
  }

}
