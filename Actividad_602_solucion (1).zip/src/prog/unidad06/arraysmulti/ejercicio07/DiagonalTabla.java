package prog.unidad06.arraysmulti.ejercicio07;

import prog.unidad06.arraysmulti.ejercicio06.TablaEnteraUtils;

public class DiagonalTabla {
  
  // Dimensiones de la tabla (Debe ser cuadrada)
  private static final int DIMENSIONES_TABLA = 10;
  
  // Limite inferior de los números aleatorios
  private static final int LIMITE_INFERIOR = 200; 
  // Limite superior de los números aleatorios
  private static final int LIMITE_SUPERIOR = 300;

  // Separación entre números al imprimir la tabla
  private static final int SEPARACION = 2;

  public static void main(String[] args) {
    // Cabecera
    System.out.println("DIAGONAL DE TABLA");
    
    // Creamos el array con el tamaño indicado y con números aleatorios
    // del rango especificado
    int[][] tabla = TablaEnteraUtils.nuevaTablaAleatoria(DIMENSIONES_TABLA
      , DIMENSIONES_TABLA, LIMITE_INFERIOR, LIMITE_SUPERIOR);
    
    // Mostramos la tabla completa
    System.out.println("Tabla original");
    TablaEnteraUtils.imprimeTabla(tabla, SEPARACION);
    
    // Inicializamos máximo, mínimo y suma para recorrer la diagonal
    // Tomamos inicialmente el valor de la esquina superior izquierda
    int maximo = tabla[0][0];
    int minimo = tabla[0][0];
    double suma = tabla[0][0];
    // Y lo imprimimos
    System.out.print("Elementos de la diagonal: ");
    System.out.print(tabla[0][0]);
    // Para cada elemento siguiente de la diagonal
    for (int i = 1; i < DIMENSIONES_TABLA; i++) {
      // Primero imprimimos la coma de separacion con el anterior y el número
      System.out.print(", " + tabla[i][i]);
      // Si el elemento es mayor que el máximo
      if (tabla[i][i] > maximo) {
        // Ahora es el nuevo máximo
        maximo = tabla[i][i];
      }
      // Si el elemento es menor que el minimo
      if (tabla[i][i] < minimo) {
        // Ahora es el nuevo mínimo
        minimo = tabla[i][i];
      }
      // Añadimos a la suma de la media
      suma += tabla[i][i];
    }
    // Imprimos salto de línea para finalizar el listado de los elementos de la diagonal
    System.out.println();
    // Ahora imprimimos el máximo, el mínimo y la media
    System.out.println("El máximo de los elementos de la diagonal es "
      + maximo + ", el mínimo es " + minimo + " y la media de todos los elementos de la diagonal vale "
      + (suma / DIMENSIONES_TABLA));
  }

}
