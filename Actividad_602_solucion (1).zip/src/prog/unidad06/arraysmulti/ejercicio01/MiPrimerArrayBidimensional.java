package prog.unidad06.arraysmulti.ejercicio01;

/**
 * Crea e imprime un array bidimensional
 */
public class MiPrimerArrayBidimensional {
  
  // Numero de filas
  private static final int FILAS = 3;
  // Numero de columnas
  private static final int COLUMNAS = 6;

  public static void main(String[] args) {
    
    // Cabecera
    System.out.println("MI PRIMER ARRAY BIDIMENSIONAL");
    
    // Crea el array
    int[][] numeros = new int[FILAS][COLUMNAS];
    
    // Y lo rellena
    numeros[0][0] = 35;
    numeros[0][2] = 64;
    numeros[0][3] = 69;
    numeros[0][5] = 93;
    numeros[1][1] = 12;
    numeros[1][4] = 92;
    numeros[1][5] = 97;
    numeros[2][0] = 13;
    numeros[2][2] = 33;
    numeros[2][4] = 52;
    
    // Imprime la tabla
    System.out.println("---------------------------");
    for (int[] fila: numeros) {
      for (int numero: fila) {
        System.out.print(String.format("%2d", numero));
        System.out.print("   ");
      }
      System.out.println();
    }
    System.out.println("---------------------------");
    
  }
  
}
