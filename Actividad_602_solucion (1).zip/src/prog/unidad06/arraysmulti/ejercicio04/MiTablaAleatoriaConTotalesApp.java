package prog.unidad06.arraysmulti.ejercicio04;

import java.util.Random;
import prog.unidad06.arraysmulti.ejercicio02.TablaEnteraConTotales;

public class MiTablaAleatoriaConTotalesApp {
  
  // Número de filas
  private static final int FILAS = 4;
  // Número de columnas
  private static final int COLUMNAS = 5;
  // Valor minimo de una casilla
  private static final int VALOR_MINIMO = 100;
  // Valor maximo de una casilla
  private static final int VALOR_MAXIMO = 999;
  
  // Parámetros de impresion
  // Ancho de cada cantidad (en dígitos)
  private static final int ANCHO = 5;
  // Separación entre numeros
  private static final int SEPARACION = 5;


  public static void main(String[] args) {
    
    // Cabecera
    System.out.println("TABLA ALEATORIA CON TOTALES");
    
    // Crea la tabla
    TablaEnteraConTotales tabla = new TablaEnteraConTotales(FILAS, COLUMNAS);
    
    // Y el objeto para obtener aleatorios
    Random random = new Random();
    
    // Rellena la tabla con aleatorios
    for (int i = 0; i < FILAS; i++) {
      for (int j = 0; j < COLUMNAS; j++) {
        tabla.setCasilla(i, j, random.nextInt(VALOR_MINIMO, VALOR_MAXIMO + 1));
      }
    }
    
    // Imprime la tabla
    // Cadena de formato para format(), incorporando el ancho 
    String formato = "%" + ANCHO + "d";
    // Separador (Se usa el metodo repeat de String que repite una cadena n veces)
    String separador = " ".repeat(SEPARACION);
    
    // Imprime la linea superior
    System.out.println("-".repeat((COLUMNAS + 1) * ANCHO + COLUMNAS * SEPARACION));
    // Para cada fila
    for (int i = 0; i < FILAS; i++) {
      // Para cada columna
      for (int j = 0; j < COLUMNAS; j++) {
        // Imprime el número con el ancho indicado
        System.out.print(String.format(formato, tabla.getCasilla(i, j)));
        // Imprime la separacion
        System.out.print(separador);
      }
      // Imprime el total de la fila junto con el salto de linea
      System.out.println(String.format(formato, tabla.getTotalFila(i)));
    }
    // Ahora imprimimos los totales de columna
    // Para cada columna
    for (int j = 0; j < COLUMNAS; j++) {
      // Imprime el total
      System.out.print(String.format(formato, tabla.getTotalColumna(j)));
      // Imprime la separacion
      System.out.print(separador);
    }
    // Imprime el total de la tabla junto con el salto de linea
    System.out.println(String.format(formato, tabla.getTotalTabla()));
    // Imprime la linea inferior
    System.out.println("-".repeat((COLUMNAS + 1) * ANCHO + COLUMNAS * SEPARACION));
  }
}
