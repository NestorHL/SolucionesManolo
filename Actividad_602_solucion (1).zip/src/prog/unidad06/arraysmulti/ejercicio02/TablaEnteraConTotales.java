package prog.unidad06.arraysmulti.ejercicio02;

/**
 * Clase que mantiene una tabla con las sumas totales de fila, columna y tabla
 */
public class TablaEnteraConTotales {
  
  // Array que almacenará la tabla
  int[][] tabla;

  /**
   * Crea la tabla. Todas las casillas estarán a cero, así como las sumas totales
   * @param filas filas que tiene la tabla. Debe ser mayor que 0
   * @param columnas Columnas que tiene la tabla. Debe ser mayor que 0
   * @throws IllegalArgumentException Si filas o columnas es menor que 1
   */
  public TablaEnteraConTotales(int filas, int columnas) {
    // Si las filas y columnas son superiores a 0
    if (filas > 0 && columnas > 0) {
      // Creamos el array con las dimensiones solicitadas. Añadimos una
      // fila y columna para los totales
      tabla = new int[filas + 1][columnas + 1];
      // Actualiza los totales
      actualizaTotales();
    } else {
      // Error. Lanzamos excepcion
      throw new IllegalArgumentException("Valor de fila o columna no válildo");
    }
  }
    
  /**
   * Modifica el valor almacenado en una casilla de la tabla
   * @param fila Posición de fila de la casilla a modificar. Desde 0 hasta el
   *   valor de filas dado en el constructor - 1
   * @param columna Posición de columna de la casilla a modificar. Desde 0 hasta
   *   valor de columnas dado en el constructor - 1
   * @param valor Valor a almacenar
   * @throws ArrayIndexOutOfBoundsException Si alguna de las posiciones no es válida
   */
  public void setCasilla(int fila, int columna, int valor) {
    // Si la posición es válida
    if (esPosicionValida(fila, columna)) {
      // Almacenamos el valor
      tabla[fila][columna] = valor;
      // Actualizamos los totales
      actualizaTotales();
    } else {
      // Fila o columna no válidas
      throw new ArrayIndexOutOfBoundsException();
    }
  }
  
  /**
   * Obtiene el valor almacenado en una casilla
   * @param fila Posición de fila de la casilla a leer. Desde 0 hasta el
   *   valor de filas dado en el constructor - 1
   * @param columna Posición de columna de la casilla a leer. Desde 0 hasta
   *   valor de columnas dado en el constructor - 1
   * @return Valor contenido en la casilla
   * @throws ArrayIndexOutOfBoundsException Si alguna de las posiciones no es válida
   */
  public int getCasilla(int fila, int columna) {
    if (esPosicionValida(fila, columna)) {
      // Obtiene el valor de la casilla
      return tabla[fila][columna];
    } else {
      // Fila o columna no válida
      throw new ArrayIndexOutOfBoundsException();
    }
  }
  
  /**
   * Obtiene la suma total de las casillas de la fila dada
   * @param fila Posición de fila de la que se quiere obtener el total. Desde 0 hasta el
   *   valor de filas dado en el constructor - 1
   * @return Total de la fila
   * @throws ArrayIndexOutOfBoundsException Si la posición de fila no es válida
   */
  public int getTotalFila(int fila) {
    if (esFilaValida(fila)) {
      return tabla[fila][tabla[fila].length - 1];
    } else {
      throw new ArrayIndexOutOfBoundsException("La posición de fila no es válida");
    }
  }
  
  /**
   * Obtiene la suma total de las casillas de la columna dada
   * @param columna Posición de columna de la casilla a leer. Desde 0 hasta
   *   valor de columnas dado en el constructor - 1
   * @return Total de la columna
   * @throws ArrayIndexOutOfBoundsException Si la posición de columna no es válida
   */
  public int getTotalColumna(int columna) {
    if (esColumnaValida(columna)) {
      return tabla[tabla.length - 1][columna];
    } else {
      throw new ArrayIndexOutOfBoundsException("La posición de columna no es válida");
    }
  }
  
  /**
   * Obtiene la suma total de todas las casillas de la tabla
   * @return Suma total de todas las casillas de la tabla
   */
  public int getTotalTabla() {
    // Devuelve el total de la tabla
    return tabla[tabla.length - 1][tabla[0].length - 1];
  }
  
  /**
   * Determina si unas coordenadas de casilla son válidas o no 
   * @param fila Coordenada de fila
   * @param columna Coordenada de columna
   * @return true si la posición es válida, false en caso contrario
   */
  private boolean esPosicionValida(int fila, int columna) {
    return esFilaValida(fila) && esColumnaValida(columna);
  }

  /**
   * Determina si la posición de fila es válida
   * @param fila Posición de fila
   * @return true si la posición de fila es válida, false en caso contrario
   */
  private boolean esFilaValida(int fila) {
    return fila >= 0 && fila < (tabla.length - 1);
  }

  /**
   * Determina si la posición de columna es válida
   * @param fila Posición de columna
   * @return true si la posición de columna es válida, false en caso contrario
   */
  private boolean esColumnaValida(int columna) {
    return columna >= 0 && columna < (tabla[0].length - 1);
  }

  /**
   * Actualiza los totales de la tabla
   */
  private void actualizaTotales() {
    
    // Precalculamos los límites de la tabla
    int filas = tabla.length;
    int columnas = tabla[0].length;
    
    // Iniciamos los totales a cero
    // Para cada fila
    for (int fila = 0; fila < filas; fila++) {
      // Iniciamos el total de la fila a cero
      tabla[fila][columnas - 1] = 0;
      // Para cada columna
      for (int columna = 0; columna < columnas; columna++) {
        // Iniciamos el total de la columna a cero
        tabla[filas - 1][columna] = 0;
      }
    }
    // Para cada fila
    for (int fila = 0; fila < filas - 1; fila++) {
      // Para cada columna
      for (int columna = 0; columna < columnas - 1; columna++) {
        // Actualizamos el total de fila
        tabla[fila][columnas - 1] += tabla[fila][columna];
        // Actualizamos el total de columna
        tabla[filas - 1][columna] += tabla[fila][columna];
        // Actualizamos el total de tabla
        tabla[filas - 1][columnas - 1] += tabla[fila][columna];
      }
    }
  }

}
