package prog.unidad06.arraysmulti.ejercicio11;

import java.util.Random;
import prog.unidad06.arraysmulti.ejercicio06.TablaEnteraUtils;

/**
 * Crea un cubo aleatorio localiza el máximo y el mínimo
 */
public class CuboAleatorioMaximoMinimoApp {
  // Dimensiones del cubo
  private static final int PLANOS = 5;
  private static final int FILAS = 6;
  private static final int COLUMNAS = 10;
  
  // Limites para la generación de los valores aleatorios
  private static final int LIMITE_INFERIOR = 0;
  private static final int LIMITE_SUPERIOR = 1000;
  
  // Separacion entre columnas
  private static final int SEPARACION = 2;

  public static void main(String[] args) {
    // Cabecera
    System.out.println("MÁXIMO Y MÍNIMO EN CUBO ALEATORIO");
    
    // Creamos el cubo
    int[][][] cubo = new int[PLANOS][FILAS][COLUMNAS];
    // Y el objeto Random para calcular números aleatorios
    Random random = new Random();
    // Para cada plano
    for (int plano = 0; plano < PLANOS; plano++) {
      // Para cada fila
      for (int fila = 0; fila < FILAS; fila++) {
        // Para cada columna
        for (int columna = 0; columna < COLUMNAS; columna++) {
          // Calculamos el valor aleatorio de la casilla
          int numero = random.nextInt(LIMITE_INFERIOR, LIMITE_SUPERIOR + 1);
          // Almacenamos el número en la casilla correspondiente
          cubo[plano][fila][columna] = numero;
        }
      }
    }
    
    // Imprimimos los planos
    for (int plano = 0; plano < PLANOS; plano++) {
      // Titulo del plano
      System.out.println("Plano " + plano );
      // Usamos TablaEnteraUtils para imprimir el plano
      TablaEnteraUtils.imprimeTabla(cubo[plano], SEPARACION);
    }
    
    // Buscamos el máximo y el mínimo, así como sus posiciones
    // Iniciamos maximo y mínimo a la primera casilla del primer plano
    // Y las posiciones a esa casilla
    int maximo = cubo[0][0][0];
    int minimo = cubo[0][0][0];
    int planoMaximo = 0;
    int filaMaximo = 0;
    int columnaMaximo = 0;
    int planoMinimo = 0;
    int filaMinimo = 0;
    int columnaMinimo = 0;
    
    // Para cada plano
    for (int plano = 0; plano < PLANOS; plano++) {
      // Para cada fila
      for (int fila = 0; fila < FILAS; fila++) {
        // Para cada columna
        for (int columna = 0; columna < COLUMNAS; columna++) {
          // Si el elementos es mayor que el máximo
          if (cubo[plano][fila][columna] > maximo) {
            // Almacenamos el máximo y la posición
            maximo = cubo[plano][fila][columna];
            planoMaximo = plano;
            filaMaximo = fila;
            columnaMaximo = columna;
          }
          // Ahora lo mismo con el mínimo
          if (cubo[plano][fila][columna] < minimo) {
            // Almacenamos el mínimo y la posición
            minimo = cubo[plano][fila][columna];
            planoMinimo = plano;
            filaMinimo = fila;
            columnaMinimo = columna;
          }
        }
      }
    }

    // Imprimos los resultados y terminamos
    System.out.println("El valor máximo es " + maximo
      + " y está situado en la posición (" + planoMaximo + ", "
      + filaMaximo + ", " + columnaMaximo + ")");
    // Imprimos los resultados y terminamos
    System.out.println("El valor mínimo es " + minimo
      + " y está situado en la posición (" + planoMinimo + ", "
      + filaMinimo + ", " + columnaMinimo + ")");
  }

}
