package prog.unidad06.arraysmulti.ejercicio10;

import java.util.Random;
import prog.unidad06.arraysmulti.ejercicio06.TablaEnteraUtils;

/**
 * Crea un cubo aleatorio y calcula las sumas de filas, columnas, segmentos y planos
 */
public class CuboAleatorioConSumasTotalesApp {
  // Dimensiones del cubo (damos una mas para el sitio para los totales)
  private static final int PLANOS = 5;
  private static final int FILAS = 4;
  private static final int COLUMNAS = 3;
  
  // Limites para la generación de los valores aleatorios
  private static final int LIMITE_INFERIOR = 100;
  private static final int LIMITE_SUPERIOR = 999;
  
  // Separacion entre columnas
  private static final int SEPARACION = 2;

  public static void main(String[] args) {
    // Cabecera
    System.out.println("CUBO ALEATORIO CON SUMAS TOTALES");
    
    // Creamos el cubo
    int[][][] cubo = new int[PLANOS][FILAS][COLUMNAS];
    // Y el objeto Random para calcular números aleatorios
    Random random = new Random();
    // Para cada plano
    for (int plano = 0; plano < (PLANOS - 1); plano++) {
      // Para cada fila
      for (int fila = 0; fila < (FILAS - 1 ); fila++) {
        // Para cada columna
        for (int columna = 0; columna < (COLUMNAS - 1); columna++) {
          // Calculamos el valor aleatorio de la casilla
          int numero = random.nextInt(LIMITE_INFERIOR, LIMITE_SUPERIOR + 1);
          // Almacenamos el número en la casilla correspondiente
          cubo[plano][fila][columna] = numero;
          // Sumamos el valor a la suma total de la fila
          cubo[plano][fila][COLUMNAS - 1] += numero;
          // Ahora a la suma total de la columna
          cubo[plano][FILAS - 1][columna] += numero;
          // Al total del plano
          cubo[plano][FILAS - 1][COLUMNAS - 1] += numero;
          // Al total del segmento
          cubo[PLANOS - 1][fila][columna] += numero;
          // Al total de la fila del segmento
          cubo[PLANOS - 1][fila][COLUMNAS - 1] += numero;
          // Al total de la columna del segmento
          cubo[PLANOS - 1][FILAS - 1][columna] += numero;
          // Y por último al total definitivo
          cubo[PLANOS - 1][FILAS - 1][COLUMNAS - 1] += numero;
        }
      }
    }
    
    // Imprimimos los planos
    for (int plano = 0; plano < PLANOS; plano++) {
      // Titulo del plano
      System.out.println("Plano " + (plano + 1));
      // Usamos TablaEnteraUtils para imprimir el plano
      TablaEnteraUtils.imprimeTabla(cubo[plano], SEPARACION);
    }
  }

}
