package prog.unidad06.arraysmulti.ejercicio05;

import java.util.Random;

/**
 * Rellena un array con números aleatorios y busca máximo y mínimo
 */
public class MaximoMinimoTablaAleatoriaApp {

  // Filas de la tabla
  private static final int FILAS = 6;
  // Columnas de la tabla
  private static final int COLUMNAS = 10;
  // Valor mínimo para obtener valores aleatorios
  private static final int VALOR_MINIMO = 0;
  // Valor máximo para obtener valores aleatorios
  private static final int VALOR_MAXIMO = 1000;
  
  // Separación entre dígitos
  private static final int SEPARACION = 2;
  
  public static void main(String[] args) {
  
    // Cabecera
    System.out.println("MÁXIMO Y MÍNIMO EN TABLA ALEATORIA");
    
    // Creamos el array y lo rellenamos con valores aleatorios
    // Creamos el array
    int[][] tabla = new int[FILAS][COLUMNAS];
    // Y lo rellenamos con valores aleatorios
    Random random = new Random();
    // Para cada elemento
    for (int i = 0; i < FILAS; i++) {
      for (int j = 0; j < COLUMNAS; j++) {
        // Asignamos valor aleatorio
        tabla[i][j] = random.nextInt(VALOR_MINIMO, VALOR_MAXIMO + 1);
      }
    }
    
    // Buscamos el máximo y el minimo
    // Iniciamos máximo y mínimo al primer elemento del array
    int maximo = tabla[0][0];
    int minimo = maximo;
    // Y las posiciones a 0,0
    int filaMaximo = 0;
    int columnaMaximo = 0;
    int filaMinimo = 0;
    int columnaMinimo = 0;
    // Recorremos la tabla completa, primero por fila y luego por columnas
    for (int i = 0; i < FILAS; i++) {
      for (int j = 0; j < COLUMNAS; j++) {
        // Si el elemento es mayor que el máximo
        if (tabla[i][j] > maximo) {
          // Almacenamos el máximo y la posición
          maximo = tabla[i][j];
          filaMaximo = i;
          columnaMaximo = j;
        }
        // Si el elemento es menor que el minimo
        if (tabla[i][j] < minimo) {
          // Almacenamos el minimo y la posición
          minimo = tabla[i][j];
          filaMinimo = i;
          columnaMinimo = j;
        }
      }
    }
    
    // Mostramos la tabla por pantalla
    // Calculamos el ancho máximo de los números de la tabla
    // Inicialmente vale cero
    int anchoMaximo = 0;
    for (int i = 0; i < tabla.length; i++) {
      for (int j = 0; j < tabla[i].length; j++) {
        // Si la longitud del número es mayor que el ancho máximo
        if (Integer.toString(tabla[i][j]).length() > anchoMaximo) {
          anchoMaximo = Integer.toString(tabla[i][j]).length();
        }
      }
    }
    
    // Cadena de formato para format(), incorporando el ancho 
    String formato = "%" + anchoMaximo + "d";
    // Separador (Se usa el metodo repeat de String que repite una cadena n veces)
    String separador = " ".repeat(SEPARACION);
    String linea = "-".repeat(COLUMNAS * anchoMaximo + (COLUMNAS - 1) * SEPARACION);
    
    // Imprime la linea superior
    System.out.println(linea);
    // Para cada fila
    for (int i = 0; i < FILAS; i++) {
      // Para cada columna
      for (int j = 0; j < COLUMNAS; j++) {
        // Imprime el número con el ancho indicado
        System.out.print(String.format(formato, tabla[i][j]));
        // Si no es el último número de la fila
        if (j < (COLUMNAS - 1)) {
          // Imprime la separacion
          System.out.print(separador);
        }
      }
      // Saltamos a la linea siguiente
      System.out.println();
    }
    // Imprime la linea inferior
    System.out.println(linea);
    
    // Y las posiciones de máximo y mínimo
    filaMaximo++;
    columnaMaximo++;
    filaMinimo++;
    columnaMinimo++;
    System.out.println("El máximo vale " + maximo
      + " y está localizado en la fila " + filaMaximo
      + ", columna " + columnaMaximo);
    System.out.println("El mínimo vale " + minimo
        + " y está localizado en la fila " + filaMinimo
        + ", columna " + columnaMinimo);
  }

}
