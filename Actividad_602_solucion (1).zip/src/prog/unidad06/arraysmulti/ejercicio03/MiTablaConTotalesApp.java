package prog.unidad06.arraysmulti.ejercicio03;

import java.util.Scanner;
import prog.unidad06.arraysmulti.ejercicio02.TablaEnteraConTotales;

public class MiTablaConTotalesApp {
  
  // Número de filas
  private static final int FILAS = 4;
  // Número de columnas
  private static final int COLUMNAS = 5;

  public static void main(String[] args) {
    // Scanner para leer desde teclado
    Scanner sc = new Scanner(System.in);
    
    // Cabecera
    System.out.println("TABLA CON TOTALES");
    
    // Crea la tabla
    TablaEnteraConTotales tabla = new TablaEnteraConTotales(FILAS, COLUMNAS);
    
    // Y la rellena
    for (int i = 0; i < FILAS; i++) {
      for (int j = 0; j < COLUMNAS; j++) {
        // Solicita el número de la casilla
        System.out.print("Introduzca el número correspondiente a la casilla (" 
          + (i + 1) + ", " + (j + 1) + "): ");
        tabla.setCasilla(i, j, Integer.parseInt(sc.nextLine()));
      }
    }
    
    // Imprime la tabla
    imprimeTabla(tabla, 3, 5, true);
    
  }

  /**
   * Imprime una tabla
   * @param tabla Tabla a imprimir
   * @param ancho Ancho de cada valor (en dígitos)
   * @param separacion Espacios de separación entre valores
   * @param lineas Si se imprime la línea de guiones antes y después de la tabla (true) o no
   *   false
   */
  private static void imprimeTabla(TablaEnteraConTotales tabla, int ancho, int separacion, boolean lineas) {
    // Cadena de formato para format(), incorporando el ancho que nos han pasado
    String formato = "%" + ancho + "d";
    // Separador (Se usa el metodo repeat de String que repite una cadena n veces)
    String separador = " ".repeat(separacion);
    
    // Imprime la linea superior (si se ha pedido)
    if (lineas) {
      imprimeLinea(COLUMNAS + 1, ancho, separacion);
    }
    // Para cada fila
    for (int i = 0; i < FILAS; i++) {
      // Para cada columna
      for (int j = 0; j < COLUMNAS; j++) {
        // Imprime el número con el ancho indicado
        System.out.print(String.format(formato, tabla.getCasilla(i, j)));
        // Imprime la separacion
        System.out.print(separador);
      }
      // Imprime el total de la fila junto con el salto de linea
      System.out.println(String.format(formato, tabla.getTotalFila(i)));
    }
    // Ahora imprimimos los totales de columna
    // Para cada columna
    for (int j = 0; j < COLUMNAS; j++) {
      // Imprime el total
      System.out.print(String.format(formato, tabla.getTotalColumna(j)));
      // Imprime la separacion
      System.out.print(separador);
    }
    // Imprime el total de la tabla junto con el salto de linea
    System.out.println(String.format(formato, tabla.getTotalTabla()));
    // Imprime la linea inferior (si es necesario)
    if (lineas) {
      imprimeLinea(COLUMNAS + 1, ancho, separacion);
    }
    
  }

  /**
   * Imprime la línea de guiones adaptada a la anchura de la tabla
   * @param columnas Número de columnas de la tabla
   * @param ancho Ancho de cada columna (en dígitos)
   * @param separacion Espacio de separación entre columnas
   */
  private static void imprimeLinea(int columnas, int ancho, int separacion) {
    System.out.println("-".repeat(columnas * ancho + (columnas - 1) * separacion));
  }

}
