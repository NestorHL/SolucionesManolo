package prog.unidad06.arraysmulti.ejercicio06;

/**
 * Rellena un array con números aleatorios y busca máximo y mínimo
 */
public class MaximoMinimoTablaAleatoriaVersion2App {

  // Filas de la tabla
  private static final int FILAS = 6;
  // Columnas de la tabla
  private static final int COLUMNAS = 10;
  // Valor mínimo para obtener valores aleatorios
  private static final int VALOR_MINIMO = 0;
  // Valor máximo para obtener valores aleatorios
  private static final int VALOR_MAXIMO = 1000;
  
  // Separación entre dígitos
  private static final int SEPARACION = 2;
  
  public static void main(String[] args) {
  
    // Cabecera
    System.out.println("MÁXIMO Y MÍNIMO EN TABLA ALEATORIA");
    
    // Creamos el array y lo rellenamos con valores aleatorios
    int[][] tabla = TablaEnteraUtils.nuevaTablaAleatoria(FILAS, COLUMNAS
      ,VALOR_MINIMO, VALOR_MAXIMO);
    
    // Buscamos el máximo y el minimo
    int maximo = TablaEnteraUtils.getMaximo(tabla);
    int minimo = TablaEnteraUtils.getMinimo(tabla);
    int[] posicionMaximo = TablaEnteraUtils.localizaMaximo(tabla);
    int[] posicionMinimo = TablaEnteraUtils.localizaMinimo(tabla);
    
    // Mostramos la tabla por pantalla
    TablaEnteraUtils.imprimeTabla(tabla, SEPARACION);
    
    // Y las posiciones de máximo y mínimo
    System.out.println("El máximo vale " + maximo
      + " y está localizado en la fila " + (posicionMaximo[0] + 1)
      + ", columna " + (posicionMaximo[1] + 1));
    System.out.println("El mínimo vale " + minimo
        + " y está localizado en la fila " + (posicionMinimo[0] + 1)
        + ", columna " + (posicionMinimo[1] + 1));
  }

}
