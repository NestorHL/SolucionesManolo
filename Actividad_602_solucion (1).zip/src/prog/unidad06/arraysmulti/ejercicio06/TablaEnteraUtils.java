package prog.unidad06.arraysmulti.ejercicio06;

import java.util.Random;

/**
 * Utilidades para manipular tablas enteras
 */
public class TablaEnteraUtils {

  /**
   * Genera una nueva tabla de las dimensiones especificadas rellena con números
   * aleatorios de un rango dado
   * @param filas Número de filas de la nueva tabla. Debe ser mayor a cero
   * @param columnas Número de columnas de la nueva tabla. Debe ser mayor a cero
   * @param inicioRango Valor de inicio del rango del que se extraerán los números aleatorios, incluido
   * @param finRango Valor de fin del rango anterior, incluido. Debe ser mayor o igual que inicioRango
   * @return Array de dos dimensiones con la tabla
   * @throws IllegalArgumentException Si filas o columnas es menor que 1 o
   *   si inicioRango es mayor que finRango
   */
  public static int[][] nuevaTablaAleatoria(int filas, int columnas, int inicioRango, int finRango) {
    // Si el número de filas es mayor que cero, el de columnas también
    // y el inicio del rango es menor o ogial que el final
    if (filas > 0 && columnas > 0 && inicioRango <= finRango) {
      // Creamos la tabla
      int[][] tabla = new int[filas][columnas];
      // Y la rellenamos con valores aleatorios
      Random random = new Random();
      // Para cada elemento
      for (int i = 0; i < filas; i++) {
        for (int j = 0; j < columnas; j++) {
          // Asignamos valor aleatorio en el rango al elemento
          tabla[i][j] = random.nextInt(inicioRango, finRango + 1);
        }
      }
      // Devolvemos la tabla
      return tabla;
    } else {
      // Algún parámetro es erróneo
      throw new IllegalArgumentException();
    }
  }
  
  /**
   * Obtiene el mayor valor contenido en la tabla
   * @param tabla Tabla donde buscar. No debe ser vacía o null
   * @return Valor máximo contenido en la tabla
   * @throws IllegalArgumentException Si la tabla es null o está vacía
   */
  public static int getMaximo(int[][] tabla) {
    // Si la tabla no es null y no está vacía
    if (tabla != null && tabla.length > 0) {
      // Iniciamos máximo al primer elemento del array
      int maximo = tabla[0][0];

      // Recorremos la tabla completa, primero por fila y luego por columnas
      for (int i = 0; i < tabla.length; i++) {
        for (int j = 0; j < tabla[i].length; j++) {
          // Si el elemento es mayor que el máximo
          if (tabla[i][j] > maximo) {
            // Almacenamos el máximo
            maximo = tabla[i][j];
          }
        }
      }
      // Devolvemos el resultado
      return maximo;
    } else {
      // Algún parámetro es incorrecto
      throw new IllegalArgumentException();
    }
  }

  /**
   * Localiza la posición del valor máximo contenido en una tabla
   * @param tabla Tabla donde localizar el máximo. No debe ser vacía o null
   * @return array de dos posiciones. La primera es la fila en la que está localizado
   *   el máximo dentro de la tabla y la segunda es la columna. Están basadas en cero.<br>
   *   En caso de que el elemento máximo aparezca varias veces se devuelve la posición de la primera
   *   aparición en orden creciente de filas y dentro de la misma fila por columnas
   * @throws IllegalArgumentException Si la tabla está vacía o es null
   */
  public static int[] localizaMaximo(int[][] tabla) {
    // Si la tabla no es null y no está vacía
    if (tabla != null && tabla.length > 0) {
      // Iniciamos máximo al primer elemento del array
      int maximo = tabla[0][0];
      // Y la posición a la cero, cero
      int[] posicion = new int[2];
      posicion[0] = 0;
      posicion[1] = 0;

      // Recorremos la tabla completa, primero por fila y luego por columnas
      for (int i = 0; i < tabla.length; i++) {
        for (int j = 0; j < tabla[i].length; j++) {
          // Si el elemento es mayor que el máximo
          if (tabla[i][j] > maximo) {
            // Almacenamos el máximo
            maximo = tabla[i][j];
            // Y la posicion
            posicion[0] = i;
            posicion[1] = j;
          }
        }
      }
      // Devolvemos el resultado
      return posicion;
    } else {
      // Tabla incorrecta
      throw new IllegalArgumentException();
    }
  }

  /**
   * Obtiene el menor valor contenido en la tabla
   * @param tabla Tabla donde buscar. No debe ser vacía o null
   * @return Valor mínimo contenido en la tabla
   * @throws IllegalArgumentException Si la tabla es null o está vacía
   */
  public static int getMinimo(int[][] tabla) {
    // Si la tabla no es null y no está vacía
    if (tabla != null && tabla.length > 0) {
      // Iniciamos mínimo al primer elemento del array
      int minimo = tabla[0][0];

      // Recorremos la tabla completa, primero por fila y luego por columnas
      for (int i = 0; i < tabla.length; i++) {
        for (int j = 0; j < tabla[i].length; j++) {
          // Si el elemento es menor que el mínimo
          if (tabla[i][j] < minimo) {
            // Almacenamos el mínimo
            minimo = tabla[i][j];
          }
        }
      }
      // Devolvemos el resultado
      return minimo;
    } else {
      // Tabla no valida
      throw new IllegalArgumentException();
    }
  }

  /**
   * Localiza la posición del valor mínimo contenido en una tabla
   * @param tabla Tabla donde localizar el mínimo. No debe ser vacía o null
   * @return array de dos posiciones. La primera es la fila en la que está localizado
   *   el mínimo dentro de la tabla y la segunda es la columna. Están basadas en cero.<br>
   *   En caso de que el elemento mínimo aparezca varias veces se devuelve la posición de la primera
   *   aparición en orden creciente de filas y dentro de la misma fila por columnas

   * @throws IllegalArgumentException Si la tabla está vacía o es null
   */
  public static int[] localizaMinimo(int[][] tabla) {
    // Si la tabla no es null y no está vacía
    if (tabla != null && tabla.length > 0) {
      // Iniciamos mínimo al primer elemento del array
      int minimo = tabla[0][0];
      // Y la posición a la cero, cero
      int[] posicion = new int[2];
      posicion[0] = 0;
      posicion[1] = 0;
  
      // Recorremos la tabla completa, primero por fila y luego por columnas
      for (int i = 0; i < tabla.length; i++) {
        for (int j = 0; j < tabla[i].length; j++) {
          // Si el elemento es menor que el mínimo
          if (tabla[i][j] < minimo) {
            // Almacenamos el mínimo
            minimo = tabla[i][j];
            // Y la posicion
            posicion[0] = i;
            posicion[1] = j;
          }
        }
      }
      // Devolvemos el resultado
      return posicion;
    } else {
      // Tabla no valida
      throw new IllegalArgumentException();
    }
  }

  /**
   * Imprime una tabla entera cualquiera por pantalla
   * @param tabla Tabla a imprimir. No debe ser null o vacía
   * @param separacion Cantidad de espacios que separan los números.
   *   Debe ser superior o igual a 1
   * @throws IllegalArgumentException Si la tabla no es correcta o la
   *   separacion es menor a 1
   */
  public static void imprimeTabla(int[][] tabla, int separacion) {
    
    // Si la tabla y la separación son correctas
    if (tabla != null && tabla.length > 0 && separacion > 0) {
      // Dimensiones de la tabla
      int filas = tabla.length;
      int columnas = tabla[0].length;
      
      // Ancho del número más grande
      int anchoMaximo = anchoMaximo(tabla);
      
      // Cadena de formato para format(), incorporando el ancho 
      String formato = "%" + anchoMaximo + "d";
      // Separador (Se usa el metodo repeat de String que repite una cadena n veces)
      String separador = " ".repeat(separacion);
      String linea = "-".repeat(columnas * anchoMaximo + (columnas - 1) * separacion);
      
      // Imprime la linea superior
      System.out.println(linea);
      // Para cada fila
      for (int i = 0; i < filas; i++) {
        // Para cada columna
        for (int j = 0; j < columnas; j++) {
          // Imprime el número con el ancho indicado
          System.out.print(String.format(formato, tabla[i][j]));
          // Si no es el último número de la fila
          if (j < (columnas - 1)) {
            // Imprime la separacion
            System.out.print(separador);
          }
        }
        // Saltamos a la linea siguiente
        System.out.println();
      }
      // Imprime la linea inferior
      System.out.println(linea);
    } else {
      throw new IllegalArgumentException();
    }
  }

  /**
   * Obtiene la longitud, en dígitos, del valor con más dígitos de una tabla
   * @param tabla Tabla con valores enteros
   * @return Longitud en dígitos del elemento más grande contenido en la tabla
   */
  private static int anchoMaximo(int[][] tabla) {
    // Inicialmente vale cero
    int ancho = 0;
    for (int i = 0; i < tabla.length; i++) {
      for (int j = 0; j < tabla[i].length; j++) {
        // Si la longitud del número es mayor que el ancho máximo
        if (Integer.toString(tabla[i][j]).length() > ancho) {
          ancho = Integer.toString(tabla[i][j]).length();
        }
      }
    }
    // Devolvemos el ancho
    return ancho;
  }
}
