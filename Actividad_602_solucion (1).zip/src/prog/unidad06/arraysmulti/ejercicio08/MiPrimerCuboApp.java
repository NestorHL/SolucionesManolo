package prog.unidad06.arraysmulti.ejercicio08;

import prog.unidad06.arraysmulti.ejercicio06.TablaEnteraUtils;

/**
 * Crea el primer cubo y los muestra
 */
public class MiPrimerCuboApp {
  
  // Dimensiones del cubo
  private static final int PLANOS = 3;
  private static final int FILAS = 4;
  private static final int COLUMNAS = 5;
  
  // Separacion entre números
  private static final int SEPARACION = 2;

  public static void main(String[] args) {
    
    // Cabecera
    System.out.println("MI PRIMER CUBO");
    
    // Creamos el cubo
    int[][][] cubo = new int[PLANOS][FILAS][COLUMNAS];
    
    // Rellenamos las casillas indicadas en las especificaciones
    // Plano 1
    cubo[0][0][0] = 18;
    cubo[0][0][2] = 36;
    cubo[0][0][3] = 67;
    cubo[0][1][1] = 59;
    cubo[0][1][3] = 6;
    cubo[0][1][4] = 40;
    cubo[0][2][0] = 74;
    cubo[0][2][2] = 59;
    cubo[0][2][4] = 11;
    cubo[0][3][1] = 51;
    cubo[0][3][2] = 85;
    cubo[0][3][3] = 62;

    // Plano 2
    cubo[1][0][1] = 25;
    cubo[1][0][2] = 38;
    cubo[1][0][3] = 99;
    cubo[1][1][0] = 92;
    cubo[1][1][2] = 31;
    cubo[1][1][4] = 74;
    cubo[1][2][1] = 78;
    cubo[1][2][2] = 81;
    cubo[1][2][4] = 76;
    cubo[1][3][0] = 1;
    cubo[1][3][1] = 26;
    cubo[1][3][3] = 96;

    // Plano 3
    cubo[2][0][2] = 17;
    cubo[2][0][3] = 42;
    cubo[2][0][4] = 82;
    cubo[2][1][1] = 95;
    cubo[2][1][2] = 8;
    cubo[2][1][3] = 50;
    cubo[2][2][0] = 2;
    cubo[2][2][1] = 96;
    cubo[2][2][2] = 29;
    cubo[2][3][0] = 21;
    cubo[2][3][1] = 74;
    cubo[2][3][4] = 48;

    // Imprimimos cada plano usando TablaEnteraUtils para imprimirlos
    for (int i = 0; i < PLANOS; i++) {
      System.out.println("Plano " + (i + 1));
      TablaEnteraUtils.imprimeTabla(cubo[i], SEPARACION);
    }
  }

}
